import numpy as np


class GMM:
	def __init__(self, k, max_iter=10):
		self.k = k
		self.max_iter = max_iter
  
	def initialize(self, X):
		 # assigning equal prob to all classes
		self.latent_var = np.full(self.k, 1/self.k)
		# self.weights = np.full((X.shape[0], self.k), 1/self.k)
		# Randomly initialize weights
		self.weights = np.random.rand(X.shape[0], self.k) 
		# random_row = np.random.randint(0, X.shape[0], self.k)
		# self.mu = [X[row_index, :] for row_index in random_row]
		# print("mu::", self.mu)
		# self.mu = X[random_row, :]
		self.sigma = [np.cov(X.T) for _ in range(self.k)] 
		#intialise mu and sigma randomly
		self.mu = X[np.random.choice(X.shape[0], self.k, replace=False)]
		#sigma random initialization using random sample from X
		# self.sigma = np.random.random_sample(size=self.k)



	def e_step(self, X):
		# E-Step: update weights and latent_var holding mu and sigma constant
		self.weights = self.predict_proba(X)
		self.latent_var = self.weights.mean(axis=0)
		# weights = np.zeros((self.k,len(X)))
		# for j in range(self.k):
		# 	weights[j,:] = norm(scale=np.sqrt(self.sigma[j])).pdf(X)
		# return weights
  
		
	def m_step(self, X):
		# M-Step: update mu and sigma holding latent_var and weights constant
		for i in range(self.k):
			weight = self.weights[:, [i]]
			total_weight = weight.sum()
			self.mu[i] = (X * weight).sum(axis=0) / total_weight
			self.sigma[i] = np.cov(X.T, aweights=(weight/total_weight).flatten(), bias=True)

	def fit(self, X):
		self.initialize(X)
		for iteration in range(self.max_iter):
			self.e_step(X)
			self.m_step(X)
   
	def multivariate_normal(self, X, mu, cov):
		d = X.shape[1]
		X = X - mu
		# Regularization: Add small constant to diagonal elements
		cov += np.eye(d) * 1e-6
		det = np.linalg.det(cov)
		if det == 0:
			raise NameError("The covariance matrix can't be singular")

		norm_const = 1.0 / (np.power((2*np.pi), float(d)/2) * np.power(det, 1.0/2))
		result = np.exp(-0.5 * np.sum(X @ np.linalg.pinv(cov) * X, axis=1))
		return norm_const * result



	def predict_proba(self, X):
		likelihood = np.zeros((X.shape[0], self.k))
		for i in range(self.k):
			likelihood[:, i] = self.multivariate_normal(X, self.mu[i], self.sigma[i])
		numerator = likelihood * self.latent_var
		denominator = numerator.sum(axis=1)[:, np.newaxis]
		weights = numerator / denominator
		return weights
		

	def predict(self, X):
		weights = self.predict_proba(X)
		return np.argmax(weights, axis=1)
	
class KMeans:
	def __init__(self, k, max_iter=10):
		self.k = k
		self.max_iter = max_iter
	
	def initialize(self, X):
		self.centroids = X[np.random.choice(X.shape[0], self.k, replace=False)]
  
	def fit(self, X):
		self.initialize(X)
		for _ in range(self.max_iter):
			self.clusters = self.predict(X)
			new_centroids = self.update_centroids(X)
			if np.all(self.centroids == new_centroids):
				break
			self.centroids = new_centroids

	def predict(self, X):
		return np.argmin(np.linalg.norm(X[:, np.newaxis] - self.centroids, axis=2), axis=1)
	
	def update_centroids(self, X):
		return np.array([X[self.clusters == k].mean(axis=0) for k in range(self.k)]) 