# import numpy as np
import pandas as pd
import math

# def calc_NMI(X,Y,bins):
#    # calcucate NMI for Normalized Mutual Information
#    # Y  is true labels and X is predicted labels

#    joint_prob = np.zeros((bins,bins))
#    for i in  range(len(X)):
#         joint_prob[X[i],Y[i]] += 1

#    joint_prob = joint_prob/len(X)

#    prob_x = np.sum(joint_prob, axis=1)
#    prob_y = np.sum(joint_prob, axis=0)
    
#    entropy_x = -np.sum(prob_x * np.log(prob_x + 1e-10))
#    entropy_y = -np.sum(prob_y * np.log(prob_y + 1e-10))

#    mutual_info = 0
#    for i in range(bins):
#          for j in range(bins):
#                if joint_prob[i,j] > 0:
#                   mutual_info += joint_prob[i,j] * np.log(joint_prob[i,j] / (prob_x[i]*prob_y[j]) + 1e-10)
   
#    nmi = mutual_info / (entropy_x + entropy_y)
#    return nmi


     

# def read_data():
#    # Load your data (replace 'your_dataset.csv' with the actual file path)
#     data = pd.read_csv('mnist_train.csv') #1st column is the label and the rest are the pixels values 28x28
   
#     # Assuming 'Outcome' is the column name for the target variable
#     X = data.drop(data.columns[[0]], axis=1).values
#     y = data[data.columns[0]].values
#     print("Y before:", y, "X before:", X)
#    #  y = np.where(y == 0, -1, 1)
#     # print("Y after:", y)    

#     # Split the data into training and testing sets
#    #  X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

#    #  return X_train, X_test, y_train, y_test 
#     return X, y

# def train_test_split(X, y, test_size=0.2, random_state=42):
#    # Complete code for getting train test split
#    np.random.seed(random_state)
#    shuffled_indices = np.random.permutation(len(X))
#    test_set_size = int(len(X) * test_size)
#    test_indices = shuffled_indices[:test_set_size]
#    train_indices = shuffled_indices[test_set_size:]
#    return X[train_indices], X[test_indices], y[train_indices], y[test_indices]

import numpy as np

np.random.seed(0)

def calc_NMI(X, Y, bins):
    # Calculate the joint probability table
    p_xy = np.histogram2d(X, Y, bins=[bins, bins])[0]
    p_xy /= np.sum(p_xy)  # Normalize to get probabilities

    # Calculate marginal probabilities
    p_x = np.sum(p_xy, axis=1)
    p_y = np.sum(p_xy, axis=0)

    # Calculate expected probabilities under independence
    p_x_y = np.outer(p_x, p_y)

    # Calculate mutual information I(X;Y)
    I_XY = np.sum(p_xy * (np.log(p_xy + 1e-9) - np.log(p_x_y + 1e-9)))

    # Calculate entropies H(X) and H(Y)
    H_X = -np.sum(p_x * np.log(p_x + 1e-9))
    H_Y = -np.sum(p_y * np.log(p_y + 1e-9))

    # Calculate normalized mutual information
    NMI = 2 * I_XY / (H_X + H_Y)

    return NMI



# def read_data():
#     # Read MNIST data from CSV file
#     data_train = np.loadtxt('PCAMnist_train.csv', delimiter=',', skiprows=1)
#     data_test = np.loadtxt('PCAMnist_test.csv', delimiter=',', skiprows=1)
#     # data_test = np.loadtxt('mnist_test.csv', delimiter=',', skiprows=1)
    
#     #length of the data_train 
#     Len_train = len(data_train)
#     # combine the train and test data
#     data = np.vstack((data_train, data_test))
#     # unique values in the first column of the data and unique values in the last column of the data
#     unique_values_fist_col = np.unique(data[:, 0])
#     unique_values_last_col = np.unique(data[:, -1])
#     # create a list which have values from 0 to 9
#     list_ = list(range(10))
#     # check if the unique values in the first column of the data is equal to the list take Y as the first column of the data
#     if np.array_equal(unique_values_fist_col, list_):
#         X = data[:, 1:]
#         y = data[:, 0]
#     # check if the unique values in the last column of the data is equal to the list take Y as the last column of the data
#     elif np.array_equal(unique_values_last_col, list_):
#         X = data[:, :-1]
#         y = data[:, -1]
#     else:
#         raise ValueError("The data is not in the expected format")
#     return X, y
def read_data_helper(filename):
    data = pd.read_csv(filename)
    X = None
    y = None
    # print("Filename: ", filename, "Data:: ", data.head())
    if   'PCA' in filename:
        #use the last colm as index and use header as 1st row
        X = data.iloc[1:, :-1].values
        y = data.iloc[1:, -1].values
        # print("Y from PCA", y)
        # print("X from PCA", X)
    else:
        X = data.iloc[:, 1:].values
        y = data.iloc[:, 0].values
        # print("Y from MNIST", y)
        # print("X from MNIST", X)

    return X, y
def read_data():
    # Read MNIST data from CSV file
   x_train, y_train= read_data_helper('PCAMnist_train.csv')
   x_test, y_test= read_data_helper('PCAMnist_test.csv')
#    x_train, y_train= read_data_helper('mnist_train.csv')
#    x_test, y_test= read_data_helper('mnist_test.csv')
#    print("shapes::", x_train.shape, x_test.shape, y_train.shape, y_test.shape)
   
   return np.vstack((x_train, x_test)), np.hstack((y_train, y_test))


def train_test_split(X, y):
    #shuffle the data:
    np.random.seed(42)
    shuffled_indices = np.random.permutation(len(X))
    X = X[shuffled_indices]
    y = y[shuffled_indices]
#extract train and test data
    trainPerc = math.floor(0.7 * len(X))
    X_train = X[:trainPerc, :]
    X_test = X[trainPerc:, :]
    y_train = y[:trainPerc]
    y_test = y[trainPerc:]
    
    return X_train, X_test, y_train, y_test