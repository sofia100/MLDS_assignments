from model import GMM,KMeans
from utils import calc_NMI,train_test_split,read_data
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans as KMeans_sklearn
from sklearn.metrics import normalized_mutual_info_score as NMI
# import numpy as np

def main() -> None:
    # set hyperparameters
    k = 10 #MNIST dataset has 10 labels
    max_iter = 10
    bins = 100
    print("code running")
    X,y = read_data()
    # print(X)
    
    # X = X[:,X.std(axis=0) != 0] # this lin
    # print(X.shape)
    # read data
    X_train,X_test,Y_train,Y_test = train_test_split(X,y)

    # normalize the data
    # X_train = (X_train - X_train.mean(axis=0)) / X_train.std(axis=0)
    # X_test = (X_test - X_test.mean(axis=0)) / X_test.std(axis=0)
    
    # create a model
    gmm = GMM(k,max_iter)
    kmeans = KMeans(k,max_iter)

    # fit the model
    gmm.fit(X_train)
    kmeans.fit(X_train)

    # evaluate the models
    gmm_nmi = calc_NMI(gmm.predict(X_test),Y_test,bins)
    kmeans_nmi = calc_NMI(kmeans.predict(X_test),Y_test,bins)
    

    print(f'Kmeans nmi={kmeans_nmi}, GMM nmi={gmm_nmi}')
    
# for comparison with sklearn library    
    gmm_model = GaussianMixture(k)
    kmeans_model = KMeans_sklearn(k)
    gmm_model.fit(X_train)
    kmeans_model.fit(X_train)
    
    print("GMM NMI by sklearn:",  NMI(gmm_model.predict(X_test),Y_test))
    print("K means NMI by sklearn:",  NMI(kmeans_model.predict(X_test),Y_test))
    
if __name__ == '__main__':
    main()