import numpy as np
from tqdm import tqdm

class SVM_class:
    def __init__(self) -> None:
        self.w = None
        self.b = None
    
    def _initialize(self, X) -> None:
        n_features = X.shape[1]
        self.w = np.random.randn(n_features)
        self.b = 0
    
    def fit(
            self, X, y, 
            learning_rate: float,
            num_iters: int,
            C: float = 1.0,
    ) -> None:
        self._initialize(X)
        rowsCount= X.shape[0]
        print("No.of rows:", rowsCount)
        
        for _ in tqdm(range(num_iters)):
            for i in range(rowsCount): #stochastic gd
                x_i = X[i]
                y_i = y[i]
                
                condition = y_i * (np.dot(self.w, x_i) + self.b) >= 1
                if condition:
                    dw = 2 * 1 / num_iters * self.w
                    db = 0
                else:
                    dw = 2 * 1 / num_iters * self.w - C * y_i * x_i
                    db = -C * y_i
                    
                # Gradient descent
                self.w -= learning_rate * dw
                self.b -= learning_rate * db
    
    def predict(self, X) -> np.ndarray:
        # return np.sign(self._linear_kernel(X))
        return np.sign(np.dot(X, self.w) + self.b)
    
    def accuracy_score(self, X, y) -> float:
        y_pred = self.predict(X)
        return np.mean(y_pred == y)
    
    def precision_score(self, X, y) -> float:
        y_pred = self.predict(X)
        tp = np.sum((y_pred == 1) & (y == 1))
        fp = np.sum((y_pred == 1) & (y == -1))
        return tp / (tp + fp) if (tp + fp) > 0 else 0
    
    def recall_score(self, X, y) -> float:
        y_pred = self.predict(X)
        tp = np.sum((y_pred == 1) & (y == 1))
        fn = np.sum((y_pred == -1) & (y == 1))
        return tp / (tp + fn) if (tp + fn) > 0 else 0
    
    def f1_score(self, X, y) -> float:
        precision = self.precision_score(X, y)
        recall = self.recall_score(X, y)
        return 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0


    
