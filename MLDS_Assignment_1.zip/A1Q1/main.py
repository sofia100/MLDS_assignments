from utils import get_data
from model import SVM_class
from typing import Tuple


def get_hyperparameters() -> Tuple[float, int, float]:
    #implement this
    # get the hyperparameters
	lr = 0.001
	itrn= 10000
	C = 0.05
	return lr, itrn, C
	
	
def main() -> None:
    # hyperparameters
	# print("runnning!")
	# for different values of Lr, C and num_iters, run the below code using for loop
	# lr_list=[0.001, 0.01, 0.1]
	# itrn_list=[100, 1000, 10000]
	# C_list=[0.01, 0.1, 1]
	# for lr in lr_list:
	# 	for itrn in itrn_list:
	# 		for C_ in C_list:
	# 			# print(f'Learning Rate={lr}, Num_iters={itrn}, C={C}')


				learning_rate, num_iters, C = get_hyperparameters()
				# learning_rate = lr
				# num_iters = itrn
				# C = C_
				print(f'Learning Rate={learning_rate}, Num_iters={num_iters}, C={C}')
				# get data
				X_train, X_test, y_train, y_test = get_data()
				print("data:", X_train[0:3])
				# create a model
				svm = SVM_class()
				# fit the model
				svm.fit(
						X_train, y_train, C=C,
						learning_rate=learning_rate,
						num_iters=num_iters,
					)
				# evaluate the model
				accuracy = svm.accuracy_score(X_test, y_test)
				precision = svm.precision_score(X_test, y_test)
				recall = svm.recall_score(X_test, y_test)
				f1_score = svm.f1_score(X_test, y_test)

				print(f'accuracy={accuracy}, precision={precision}, recall={recall}, f1_score={f1_score}')


if __name__ == '__main__':
    main()
